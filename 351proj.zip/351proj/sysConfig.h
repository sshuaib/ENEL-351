#include <stdint.h>

void clockInitial(void);	// Clock initialization providing a default SYSCLK of 24 MHz using the PLL and clock visibility of PLL/2 on PA8
