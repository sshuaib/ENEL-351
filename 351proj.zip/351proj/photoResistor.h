#include "stdint.h"
#include "stm32f10x.h"

void photoResistor(void);	
