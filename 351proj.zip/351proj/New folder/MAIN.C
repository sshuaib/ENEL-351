#include "stm32f10x.h"
#include "init.h"

int main()
{
	
	 clockInit();
	 //tim1_IO_init();
	 //tim1GPIOSetup(50);
	 //tim2_IO_init();
	 //tim2GPIOSetup(50);
	 //tim3_IO_init();
	 //tim3GPIOSetup(50);
	 configGPIO();
	
	/*while(1)
	{
		blueButton();
	}*/
		while(1)
	{
		
		/*--------------------------------Servo-----------------------------------*/
		rightmotor_on();
		delay(2000);
		rightmotor_high();
		delay(1000);
		leftmotor_on();
		delay(2000);
		leftmotor_high();
		delay(1000);
		//rightmotor_off();
		//delay(1000);
	} 
}

